var n=1;
function primero() {
    n=1;
    actualizar();
}
function ultimo() {
    n=11;
    actualizar();
}
function anterior() {
    if (n>1) {
        n--;
    }
    actualizar();
}
function siguiente() {
    if (n<11) {
        n++;
    }
    actualizar();
}
function actualizar() {
    document.getElementById("fotos").src="23/foto"+n+".png";
    if (n==1) {
        document.getElementById("butPrimero").src="23/firstOFF.png";
        document.getElementById("butAnterior").src="23/previousOFF.png";
        document.getElementById("butSiguiente").src="23/nextON.png";
        document.getElementById("butUltimo").src="23/lastON.png";
    }
    if (n==1) {
        document.getElementById("butPrimero").src="23/firstON.png";
        document.getElementById("butAnterior").src="23/previousON.png";
        document.getElementById("butUltimo").src="23/lastOFF.png";
    }
    if (n==1) {
        document.getElementById("butPrimero").src="23/firstON.png";
        document.getElementById("butAnterior").src="23/previousON.png";
        document.getElementById("butSiguiente").src="23/nextON.png";
        document.getElementById("butUltimo").src="23/lastON.png";
    }
}