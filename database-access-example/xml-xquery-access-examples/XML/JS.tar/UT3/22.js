/*
 *  El NIF (o letra asociada a un DNI) se obtiene de la siguiente manera: 
 *  Se divide el número de DNI entre 23 y el resto es codificado por una letra según la siguiente equivalencia:
 *    - 0: "T", 1: "R", 2: "W", 3: "A", 4: "G", 5: "M", 6: "Y", 7: "F", 8: "P", 9: "D",10:"X", 11: "B",
 *    - 12: "N", 13: "J", 14: "Z", 15: "S", 16: "Q", 17: "V", 18: "H", 19: "L", 20: "C", 21: "K", 22: "E".
 *  Escribe un programa que pida el número de DNI y muestre por pantalla la letra asociada.
 */

        // "Esta variable almacenará los números del DNI para poder operar con ellos.";
        var numDNI = 0;

        // "Estas son las variables que se imprimirán dependiendo del resultado del resto.";
        var T = 'T';
        var R = 'R';
        var W = 'W';
        var A = 'A';
        var G = 'G';
        var M = 'M';
        var Y = 'Y';
        var F = 'F';
        var P = 'P';
        var D = 'D';
        var X = 'X';
        var B = 'B';
        var N = 'N';
        var J = 'J';
        var Z = 'Z';
        var S = 'S';
        var Q = 'Q';
        var V = 'V';
        var H = 'H';
        var L = 'L';
        var C = 'C';
        var K = 'K';
        var E = 'E';

        // "Dependiendo de si la vuelta del bucle es la primera o no ejecutara una instrucción u otra.";
        var vueltaBucle1 = true;

        // "Ejecuta al menos una vez la entrada de datos del usuario.";
        do {

            // "En la primera vuelta del bucle se imprimirá un mensaje que será diferente al que se empezara a imprimir de la vuelta 2.";
            if (vueltaBucle1 == true) {
                numDNI = prompt("Introduzca el número de DNI del cual se quiere obtener la letra:");
            }

            else if (vueltaBucle1 == false) {
                document.write ("El número de DNI no puede contener decimales.");
                document.write ("El número de DNI no puede ser mayor a su máxima combinación 99999999, formada por un total de 8 dígitos.");
                document.write ("El número de DNI no puede ser menor a su mínima combinación 00000000, formada por un total de 8 dígitos.");
                numDNI = prompt("Introduzca de nuevo el DNI en el formato válido:");
            }

        // "Rango de dígitos permitidos en el DNI.";
        // "Los 10000000 números contienen ceros a la izquierda es lo mismo dividir entre (00000432) que entre (432) el resto va a ser igual";
        } while (numDNI < 0 && numDNI > 99999999);

        // "Fin del algoritmo y de las instrucciones mostramos el valor de letra obtenido dependiendo del resto de la división.";
        switch (numDNI % 23) {

            case 0:
                document.write ('El DNI introducido será validado con la letra ' + T);
                break;

            case 1:
                document.write ("El DNI introducido será validado con la letra " + R);
                break;

            case 2:
                document.write ("El DNI introducido será validado con la letra " + W);
                break;

            case 3:
                document.write ("El DNI introducido será validado con la letra " + A);
                break;

            case 4:
                document.write ("El DNI introducido será validado con la letra " + G);
                break;

            case 5:
                document.write ("El DNI introducido será validado con la letra " + M);
                break;

            case 6:
                document.write ("El DNI introducido será validado con la letra " + Y);
                break;

            case 7:
                document.write ("El DNI introducido será validado con la letra " + F);
                break;

            case 8:
                document.write ("El DNI introducido será validado con la letra " + P);
                break;

            case 9:
                document.write ("El DNI introducido será validado con la letra " + D);
                break;

            case 10:
                document.write ("El DNI introducido será validado con la letra " + X);
                break;

            case 11:
                document.write ("El DNI introducido será validado con la letra " + B);
                break;

            case 12:
                document.write ("El DNI introducido será validado con la letra " + N);
                break;

            case 13:
                document.write ("El DNI introducido será validado con la letra " + J);
                break;

            case 14:
                document.write ("El DNI introducido será validado con la letra " + Z);
                break;

            case 15:
                document.write ("El DNI introducido será validado con la letra " + S);
                break;

            case 16:
                document.write ("El DNI introducido será validado con la letra " + Q);
                break;

            case 17:
                document.write ("El DNI introducido será validado con la letra " + V);
                break;

            case 18:
                document.write ("El DNI introducido será validado con la letra " + H);
                break;

            case 19:
                document.write ("El DNI introducido será validado con la letra " + L);
                break;

            case 20:
                document.write ("El DNI introducido será validado con la letra " + C);
                break;

            case 21:
                document.write ("El DNI introducido será validado con la letra " + K);
                break;

            case 22:
                document.write ("El DNI introducido será validado con la letra " + E);
                break;

            default:
                document.write ("Ha ocurrido un error por favor inténtelo denuedo.");
                break;
		
        }

    

