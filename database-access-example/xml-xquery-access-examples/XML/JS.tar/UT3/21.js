// script externo 21.js

var hoy   = new Date();
var dia   = hoy.getDate();
var n_mes = hoy.getMonth();
var mes   = ('enero','Febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre');
var anyo  = hoy.getFullYear();

alert("Hoy es " + dia + " del " + mes + " de " + anyo );
document.write("Hoy es " + dia + " del " + mes + " de " + anyo );