var respuesta = " ";
var solucion = 5;
var contador = 0;

while (respuesta != solucion) {
    respuesta = prompt("¿Cuántos dedos tiene una mano?","");
    contador++;
}

document.write("Has acertado a la " + contador + " vez.");