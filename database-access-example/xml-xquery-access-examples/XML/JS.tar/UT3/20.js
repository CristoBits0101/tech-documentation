// script externo 20.js

var hoy  = new Date();
var dia  = hoy.getDate();
var mes  = hoy.getMonth()+1;
var anyo = hoy.getFullYear();

alert("Hoy es " + dia + " del " + mes + " de " + anyo );
document.write("Hoy es " + dia + " del " + mes + " de " + anyo );